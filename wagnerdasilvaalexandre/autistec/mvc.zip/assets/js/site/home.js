/**
*
* Script do site
*
* @author Gustavo Paes
*
**/
;(function($, URL){

	var exemplo = function(){
		
	}

	$(function(){
		exemplo();
	});

})($, URL);

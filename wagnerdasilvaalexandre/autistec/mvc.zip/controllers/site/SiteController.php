<?php

/**
*
* Controller do site.
*
* @author Gustavo Paes
*
**/
class SiteController extends Controller
{


}
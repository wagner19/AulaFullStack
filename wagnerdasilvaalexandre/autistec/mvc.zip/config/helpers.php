<?php

/**
*
* Arquivo onde são definidos os helpers
*
* @author Gustavo Paes
*
**/

define('LOCAL_URL', '/gustavo/mvc');

if($env == "dev"){
	define('LOCAL_URL', '/gustavo/mvc');
}
elseif($env == "prod"){
	define('LOCAL_URL', 'https://wwww.google.com.br/');
}


return array(
	'URLHelper' 	=> new URLHelper(),
);